
public class NodeTester 
{
	public static void main(String[] args)
	{
		LinkedIntList list = new LinkedIntList();
		
		for(int i = 1; i <= 10; i++)
		{
			list.add(i);
		}
		
		System.out.println(list);
		System.out.println();
		System.out.println(list.get(6));
		System.out.println();
		list.add(4, 69);
		System.out.println(list);
		System.out.println(list.isSorted());
		list.remove(4);
		System.out.println(list);
		System.out.println();
		System.out.println(list.IndexOf(9));
		System.out.println(list.isSorted());
		System.out.println();
		
		LinkedIntList list1 = new LinkedIntList();
		list1.add(2);
		list1.add(5);
		list1.add(12);
		list1.addSorted(10);
		System.out.println(list1);
		System.out.println();
		list1.set(2, 9);
		list1.set(0, 1);
		System.out.println();
		
		LinkedIntList list2 = new LinkedIntList();
		list2.add(1);
		list2.add(5);
		list2.add(12);
		list2.add(3);
		list2.add(13);
		list2.add(21);
		list2.add(13);
		list2.add(2);
		System.out.println(list2);
		System.out.println(list2.min());
		System.out.println(list2.isSorted());
		System.out.println(list2.lastIndexOf(13));
		
		LinkedIntList list3 = new LinkedIntList();
		list3.add(1);
		list3.add(1);
		list3.add(1);
		list3.add(3);
		list3.add(3);
		list3.add(6);
		list3.add(9);
		list3.add(15);
		list3.add(15);
		list3.add(23);
		list3.add(23);
		list3.add(23);
		list3.add(40);
		list3.add(40);
		System.out.println(list3);
		System.out.println(list3.countDuplicates());
		System.out.println();
		
		LinkedIntList list4 = new LinkedIntList();
		list4.add(1);
		list4.add(18);
		list4.add(2);
		list4.add(7);
		list4.add(8);
		list4.add(39);
		list4.add(18);
		list4.add(40);
		System.out.println(list4);
		System.out.println(list4.hasTwoConsecutive());
		System.out.println();
		
		LinkedIntList list5 = new LinkedIntList();
		list5.add(1);
		list5.add(18);
		list5.add(17);
		list5.add(2);
		list5.add(7);
		list5.add(39);
		list5.add(18);
		list5.add(40);
		list.add(8);
		System.out.println(list5);
		System.out.println(list5.hasTwoConsecutive());
		System.out.println();
		
		LinkedIntList list6 = new LinkedIntList();
		list6.add(1);
		list6.add(12);
		list6.add(2);
		list6.add(7);
		list6.add(9);
		list6.add(39);
		list6.add(18);
		list6.add(19);
		System.out.println(list6);
		System.out.println(list6.hasTwoConsecutive());
		System.out.println();
		
		list2.sortList();
		System.out.println(list2);
		System.out.println();
		
		LinkedIntList list7 = new LinkedIntList();
		list7.add(3);
		list7.add(12);
		list7.add(2);
		list7.add(3);
		list7.add(9);
		list7.add(3);
		list7.add(18);
		list7.add(19);
		list7.add(3);
		System.out.println(list7);
		list7.removeValue(3);
		System.out.println(list7);
		System.out.println();
		
		LinkedIntList list8 = new LinkedIntList();
		list8.add(1);
		list8.add(8);
		list8.add(19);
		list8.add(4);
		list8.add(17);
		System.out.println(list8);
		list8.stutter();
		System.out.println(list8);
		System.out.println();
		
		LinkedIntList list9 = new LinkedIntList();
		list9.add(8);
		list9.add(17);
		list9.add(2);
		list9.add(4);
		System.out.println(list9);
		LinkedIntList list10 = new LinkedIntList();
		list10.add(1);
		list10.add(2);
		list10.add(3);
		System.out.println(list10);
		System.out.println();
		list9.transferFrom(list10);
		System.out.println(list9);
		System.out.println(list10);
		System.out.println();
		
		LinkedIntList list11 = new LinkedIntList();
		list11.add(8);
		list11.add(13);
		list11.add(17);
		list11.add(4);
		list11.add(9);
		list11.add(12);
		list11.add(98);
		list11.add(41);
		list11.add(7);
		list11.add(23);
		list11.add(0);
		list11.add(92);
		System.out.println(list11);
		LinkedIntList list12 = list11.removeEvens();
		System.out.println(list12);
		System.out.println(list11);
		System.out.println();
		
		LinkedIntList list13 = new LinkedIntList();
		list13.add(8);
		list13.add(7);
		list13.add(-4);
		list13.add(19);
		list13.add(0);
		list13.add(43);
		list13.add(-8);
		list13.add(-7);
		list13.add(2);
		System.out.println(list13);
		list13.split();
		System.out.println(list13);
		System.out.println();
		
		LinkedIntList list14 = new LinkedIntList();
		list14.add(8);
		list14.add(13);
		list14.add(17);
		list14.add(4);
		list14.add(9);
		list14.add(12);
		list14.add(98);
		list14.add(41);
		list14.add(7);
		list14.add(23);
		list14.add(0);
		list14.add(92);
		System.out.println(list14);
		list14.removeRange(3, 8);
		System.out.println(list14);
		System.out.println();
		
		list14.forwardTraversal();
		System.out.println();
		list14.backwardTraversal();
		System.out.println();
		System.out.println();
		
		LinkedIntList list15 = new LinkedIntList();
		list15.add(3);
		list15.add(7);
		list15.add(4);
		list15.add(9);
		list15.add(8);
		list15.add(12);
		list15.add(2);
		System.out.println(list15);
		list15.switchPairs();
		System.out.println(list15);
		System.out.println();
		
		LinkedIntList list16 = new LinkedIntList();
		list16.add(8);
		list16.add(23);
		list16.add(19);
		list16.add(7);
		list16.add(45);
		list16.add(98);
		list16.add(102);
		list16.add(4);
		System.out.println(list16);
		list16.rotate();
		System.out.println(list16);
	}
}