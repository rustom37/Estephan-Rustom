
public class IntTree
{
	public IntTreeNode overallRoot;
	
	public IntTree()
	{
		overallRoot = null;
	}
	
	public IntTree(int value, int level)
	{
		overallRoot = buildTree(value, 0, level);
	}
	
	public void printPreorder()
	{
		System.out.print("Preorder: ");
		printPreorder(overallRoot);
		System.out.println();
	}
	
	public void printInorder()
	{
		System.out.print("Inorder: ");
		printInorder(overallRoot);
		System.out.println();
	}
	
	public void printPostorder()
	{
		System.out.println("Postorder: ");
		printPostorder(overallRoot);
		System.out.println();
	}
	
	public void printSideways()
	{
		printSideways(overallRoot, 0);
	}
	
	public int sumTree()
	{
		return sumTree(overallRoot);
	}
	
	public int countLevels()
	{
		return countLevels(overallRoot);
	}
	
	public int countLeaves()
	{
		return countLeaves(overallRoot);
	}
	
	private int countLeaves(IntTreeNode root)
	{
		if(root == null)
		{
			return 0;
		}
		else if(root.left == null && root.right == null)
		{
			return 1;
		}
		else
		{
			return countLeaves(root.left) + countLeaves(root.right);
		}
	}
	
	private int countLevels(IntTreeNode root)
	{
		if(root == null)
		{
			return 0;
		}
		else
		{
			return 1 + Math.max(countLevels(root.left), countLevels(root.right));
		}
	}
	
	private int sumTree(IntTreeNode root)
	{
		if(root == null)
		{
			return 0;
		}
		else
		{
			return root.data + sumTree(root.left) + sumTree(root.right);
		}
	}
	
	private void printSideways(IntTreeNode root, int level)
	{
		if(root != null)
		{
			printSideways(root.right, level+1);
			for(int i = 0; i < level; i++)
			{
				System.out.print("   ");
			}
			System.out.println(root.data);
			printSideways(root.left, level+1);
		}
	}
	
	private void printPostorder(IntTreeNode root)
	{
		if(root != null)
		{
			printPostorder(root.left);
			printPostorder(root.right);
			System.out.print(" " + root.data);
		}
	}	
	
	private void printInorder(IntTreeNode root)
	{
		if(root != null)
		{
			printInorder(root.left);
			System.out.print(" " + root.data);
			printInorder(root.right);
		}
	}
	
	private void printPreorder(IntTreeNode root)
	{
		if(root != null)
		{
			System.out.print(" " + root.data);
			printPreorder(root.left);
			printPreorder(root.right);
		}
	}
	
	private IntTreeNode buildTree(int n, int counter, int level)
	{
		if(level == 0)
		{
			return null;
		}
		else if(counter < level)
		{
			IntTreeNode left = buildTree(2 * n, counter++, level);
			IntTreeNode right = buildTree((2 * n) + 1, counter++, level);
			
			return new IntTreeNode(n, left, right);
		}
		else
		{
			return null;
		}
	}
}