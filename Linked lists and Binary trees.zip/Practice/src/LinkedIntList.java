import java.util.*;

public class LinkedIntList 
{
	ListNode front;
	
	public LinkedIntList()
	{
		front = null;
	}
	
	public String toString()
	{
		String s;
		
		if(front == null)
		{
			return "[]";
		}
		else
		{
			s = "[" + front.data;
			ListNode current = front.next;
			
			while(current != null)
			{
				s += ", " + current.data;
				current = current.next;
			}
			
			s += "]";
			return s;
		}
	}
	
	public void add(int data)
	{
		if(front == null)
		{
			front = new ListNode(data);
		}
		else
		{
			ListNode current = front;
			
			while(current.next != null)
			{
				current = current.next;
			}
			
			current.next = new ListNode(data);
		}
	}
	
	public int get(int index)
	{
		return NodeAt(index).data;
	}
	
	public void add(int index, int value)
	{
		if(index == 0)
		{
			front = new ListNode(value, front);
		}
		else
		{
			ListNode current = front;
			
			current = NodeAt(index - 1);
			
			current.next = new ListNode(value, current.next);
		}
	}
	
	public void remove(int index)
	{
		if(index == 0)
		{
			front = front.next;
		}
		else
		{
			ListNode current = front;
			
			current = NodeAt(index - 1);
			
			current.next = current.next.next;
		}
	}
	
	public int getSize()
	{
		ListNode current = front;
		int count = 0;
		
		while(current != null)
		{
			current = current.next;
			count++;
		}
		
		return count;
	}
	
	public int IndexOf(int value)
	{
		ListNode current = front;
		int count = 0;
		
		while(current != null)
		{
			if(current.data == value)
			{
				return count;
			}
			current = current.next;
			count++;
		}
		return -1;
	}
	
	public void addSorted(int value)
	{
		if(front == null || front.data >= value)
		{
			front = new ListNode(value, front);
		}
		else
		{
			ListNode current = front;
			
			while(current.next != null && current.next.data < value)
			{
				current = current.next;
			}
			
			current.next = new ListNode(value, current.next);
		}
	}
	
	public void set(int index, int value)
	{
		if(index == 0)
		{
			front.data = value;
		}
		else
		{
			ListNode current = front;
			current = NodeAt(index - 1);
			current.next.data = value;
		}
	}
	
	public int min()
	{
		if(front == null)
		{
			NoSuchElementException exception = new NoSuchElementException();
			throw exception;
		}
		else
		{
			ListNode current = front;
			int min = front.data;
			
			while(current != null)
			{
				if(current.data < min)
				{
					min = current.data;
				}
				
				current = current.next;
			}
			
			return min;
		}
	}
	
	public boolean isSorted()
	{
		if(front == null)
		{
			return true;
		}
		else
		{
			ListNode current = front;
			
			while(current.next != null)
			{
				if(current.data > current.next.data)
				{
					return false;
				}
				
				current = current.next;
			}
			
			return true;
		}
	}
	
	public int lastIndexOf(int value)
	{
		int count = 0;
		int index = -1;
		ListNode current = front;
		
		while(current != null)
		{
			if(current.data == value)
			{
				index = count;
			}
			current = current.next;
			count++;
		}
		
		if(current == null && index == -1)
		{
			return -1;
		}
		else
		{
			return index;
		}
	}
	
	public int countDuplicates()
	{
		ListNode current = front;
		int duplicates = 0;
		
		while(current.next != null)
		{
			if(current.data == current.next.data)
			{
				duplicates++;
			}
			current = current.next;
		}
		
		return duplicates;
	}
	
	public boolean hasTwoConsecutive()
	{
		if(front == null)
		{
			return false;
		}
		else
		{
			ListNode current = front;
			
			while(current.next != null)
			{
				if((current.data + 1) == current.next.data)
				{
					return true;
				}
				
				current = current.next;
			}
			return false;
		}
	}
	
	public void sortList()
	{
		ListNode current = front;
		LinkedIntList list = new LinkedIntList();
		
		while(current != null)
		{
			list.addSorted(current.data);
			current = current.next;
		}
		
		front = list.front;
	}
	
	public void removeValue(int value)
	{
		if(front.data == value)
		{
			front = front.next;
		}
		
		ListNode current = front;
			
		while(current.next != null)
		{
			if(current.next.data == value)
			{
				remove(IndexOf(value));
			}
			else
			{
				current = current.next;
			}
		}
	}
	
	public void stutter()
	{
		ListNode current = front;
		
		while(current != null)
		{
			ListNode node = new ListNode(current.data);
			
			node.next = current.next;
			current.next = node;
			
			current = current.next.next;
		}
	}
	
	public void transferFrom(LinkedIntList list)
	{
		ListNode current = front;
		
		while(current.next != null)
		{
			current = current.next;
		}
		
		current.next = list.front;
		
		int size = list.getSize();
		
		for(int i = 0; i < size; i++)
		{
			list.remove(0);
		}
	}
	
	public LinkedIntList removeEvens()
	{
		LinkedIntList list = new LinkedIntList();
		
		list.front = front;
		ListNode curr2 = list.front;
		ListNode curr1 = front.next;
		front=curr1;
		while(curr2 != null)
		{
			if(curr2.next != null)
			{
				curr2.next = curr2.next.next;
				curr2 = curr2.next;
				
				if(curr1.next != null)
				{
					curr1.next = curr1.next.next;
					curr1 = curr1.next;					
				}
			}
		}
		return list;
	}
	
	public void split()
	{
		ListNode current = front;
		int index = 0;
		
		while(current != null)
		{
			if(current.data < 0)
			{
				int x = current.data;
				remove(index);
				add(0, x);
			}
			
			current = current.next;
			index++;
		}
	}
	
	public void removeRange(int start, int end)
	{
		if(start < 0 || end < 0)
		{
			IllegalArgumentException exception = new IllegalArgumentException("Either of the positions is negative.");
			throw exception;
		}
		
		ListNode current = front;
		int index = 0;
		
		while(current != null)
		{
			if(index == start)
			{
				for(int i = 0; i <= (end - start); i++)
				{
					remove(index);
				}
			}
			
			index++;
			current = current.next;
		}
	}	
	
	public void forwardTraversal()
	{
		forwardTraversal(front);
	}
	
	public void backwardTraversal()
	{
		backwardTraversal(front);
	}
	
	public void switchPairs()
	{
		if(front == null)
		{
			return;
		}
		else
		{
			ListNode current = front;
			
			while(current.next != null)
			{
				int x = current.data;
				
				current.data = current.next.data;
				current.next.data = x;
				
				if(current.next.next != null)
				{
					current = current.next.next;
				}
				else
				{
					break;
				}
			}
		}
	}
	
	public void rotate()
	{
		if(front == null || front.next == null)
		{
			return;
		}
		else
		{
			ListNode current = front;
			add(current.data);
			front = front.next;
		}
	}
	
	private ListNode NodeAt(int index)
	{
		ListNode current = front;
			
		for(int i = 0; i < index; i++)
		{
			current = current.next;
		}
		
		return current;
	}
	
	private void forwardTraversal(ListNode node)
	{
		ListNode current = node;
		
		if(current.next == null)
		{
			System.out.print(current.data);
		}
		else
		{
			System.out.print(current.data + " --> ");
			forwardTraversal(current.next);
		}
	}
	
	private void backwardTraversal(ListNode node)
	{
		ListNode current = node;
		
		if(current.next == null)
		{
			System.out.print(current.data);
		}
		else
		{
			backwardTraversal(current.next);
			System.out.print(" --> " + current.data);
		}
	}
}