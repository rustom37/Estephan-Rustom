import java.util.*;

public class SearchIntTree
{
	public IntTreeNode overallRoot;
	
	public SearchIntTree()
	{
		overallRoot = null;
	}
	
	public void add(int value)
	{
		overallRoot = add(overallRoot, value);
	}
	
	public boolean contains(int value)
	{
		return contains(overallRoot, value);
	}
	
	public void printPreorder()
	{
		System.out.print("Preorder: ");
		printPreorder(overallRoot);
		System.out.println();
	}
	
	public void printInorder()
	{
		System.out.print("Inorder: ");
		printInorder(overallRoot);
		System.out.println();
	}
	
	public void printPostorder()
	{
		System.out.println("Postorder: ");
		printPostorder(overallRoot);
		System.out.println();
	}
	
	public void printSideways()
	{
		printSideways(overallRoot, 0);
	}
	
	public void print()
	{
		printInorder(overallRoot);
		System.out.println();
	}
	
	public int getMin()
	{
		if(overallRoot == null)
		{
			throw new IllegalArgumentException();
		}
		
		return getMin(overallRoot);			
	}
	
	public void remove(int value)
	{
		overallRoot = remove(overallRoot, value);
	}
	
	public ArrayList<Integer> treeToAL()
	{
		ArrayList<Integer> list = new ArrayList<Integer>();
		return treeToAL(overallRoot, list);
	}
	
	private ArrayList<Integer> treeToAL(IntTreeNode root, ArrayList<Integer> list)
	{
		if(root == null)
		{
			return list;
		}
		else
		{
			treeToAL(root.left, list);
			list.add(root.data);
			treeToAL(root.right, list);
			
			return list;
		}	
	}
	
	private IntTreeNode remove(IntTreeNode root, int value)
	{
		if(root == null)
		{
			return null;
		}
		else if(root.data > value)
		{
			return remove(root.left, value);
		}
		else if(root.data < value)
		{
			return remove(root.right, value);
		}
		else
		{
			if(root.left == null)
			{
				return root.right;
			}
			else if(root.right == null)
			{
				return root.left;
			}
			else
			{
				root.data = getMin(root.right);
				root.right = remove(root.right, root.data);
			}
			return root;
		}
	}
	
	private int getMin(IntTreeNode root)
	{
		if(root.left == null)
		{
			return root.data;
		}
		else
		{
			return getMin(root.left);
		}
	}
	
	private boolean contains(IntTreeNode root, int value)
	{
		if(root == null)
		{
			return false;
		}
		else if(root.data == value)
		{
			return true;
		}
		else if(value < root.data)
		{
			return contains(root.left, value);
		}
		else
		{
			return contains(root.right, value);
		}
	}
	
	private IntTreeNode add(IntTreeNode root, int value)
	{
		if(root == null)
		{
			root =  new IntTreeNode(value);
		}
		else if(value < root.data)
		{
			root.left = add(root.left, value);
		}
		else if(value > root.data)
		{
			root.right = add(root.right, value);
		}
		return root;			
	}
	
	private void printSideways(IntTreeNode root, int level)
	{
		if(root != null)
		{
			printSideways(root.right, level+1);
			for(int i = 0; i < level; i++)
			{
				System.out.print("   ");
			}
			System.out.println(root.data);
			printSideways(root.left, level+1);
		}
	}
	
	private void printPostorder(IntTreeNode root)
	{
		if(root != null)
		{
			printPostorder(root.left);
			printPostorder(root.right);
			System.out.print(" " + root.data);
		}
	}	
	
	private void printInorder(IntTreeNode root)
	{
		if(root != null)
		{
			printInorder(root.left);
			System.out.print(" " + root.data);
			printInorder(root.right);
		}
	}
	
	private void printPreorder(IntTreeNode root)
	{
		if(root != null)
		{
			System.out.print(" " + root.data);
			printPreorder(root.left);
			printPreorder(root.right);
		}
	}
}