import java.util.*;

public class ArrayIntList
{
	private int size;
	private int[] array;
	public static final int DEFAULT_CAPACITY = 10;
	
	public ArrayIntList()
	{
		this(DEFAULT_CAPACITY);
	}
	
	public ArrayIntList(int capacity)
	{
		size = 0;
		array = new int[capacity];
	}
	
	public void add(int value)
	{
		array[size] = value;
		size++;
		checkResize();
	}
	
	public void add(int index, int value)
	{
		for(int i = size - 1; i >= index; i--)
		{
			array[i+1] = array[i];
			checkResize();
		}
		
		array[index] = value;
		size++;
	}
	
	public int get(int index)
	{
		if (index < 0 || index >= size)
		{
	        throw new ArrayIndexOutOfBoundsException();
	    }

		return array[index];
	}
	
	public void set(int index, int value)
	{
		array[index] = value;
	}
	
	public int size()
	{
		return size;
	}
	
	public boolean isEmpty()
	{
		if(size == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void remove(int index)
	{
		for(int i = index; i < size; i++)
		{
			array[i] = array[i+1];
		}
		
		size--;
		array[size] = 0;
	}
	
	public String toString()
	{
		String s = "[" + array[0];
		
		for(int i = 1; i <= size - 1; i++)
		{
			s += ", " + array[i];
		}
		
		s += "]";
		
		return s;
	}
	
	public int IndexOf(int value)
	{
		for(int i = 0; i <= size -1; i++)
		{
			if(array[i] == value)
			{
				return i;
			}
		}
		
		return -1;
	}
	
	public boolean contains(int value)
	{
		return IndexOf(value) >= 0;
	}
	
	private void checkResize()
	{
		if(size == array.length)
		{
			array = Arrays.copyOf(array, 2 * size);
		}
	}
}