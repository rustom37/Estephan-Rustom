import java.util.*;

public class TreeTester 
{    
    public static void main(String[] args) 
    {
        //construct an empty tree
        SearchIntTree bst1 = new SearchIntTree();
        
        //add nodes to it making it a binary searh tree
        bst1.add(7);
        bst1.add(3);
        bst1.add(1);
        bst1.add(4);
        bst1.add(8); 
       //print side ways the tree
        bst1.printSideways();
        System.out.println();
        System.out.println();
        
         SearchIntTree bst2 = new SearchIntTree();
         bst2.add(3);
         bst2.add(2);
         bst2.add(1);
         bst2.add(8);
         bst2.add(7);
         bst2.add(9);
        
        bst2.printSideways();
        System.out.println();    
        System.out.println();
        System.out.println(bst2.treeToAL());
        System.out.println();
        
        int[] array = {5, 8, 6, 1, 2, 7, 4, 9, 3};
        BSTSort(array);
        System.out.println(Arrays.toString(array));
    }
    
    public static void BSTSort(int[] a)
    {
    	SearchIntTree tree = new SearchIntTree();
    	
    	for(int i = 0; i <= a.length - 1; i++)
    	{
    		tree.add(a[i]);
    	}
    	
    	ArrayList<Integer> list = tree.treeToAL();
    	
    	for(int i = 0; i<= a.length - 1; i++)
    	{
    		a[i] = list.get(i);
    	}
    }
}