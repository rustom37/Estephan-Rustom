
public class ArrayIntListTester 
{
	public static void main(String[] args) 
	{
		ArrayIntList list = new ArrayIntList();
		
		for(int i = 1; i <= 10; i++)
		{
			list.add(i);
		}
		
		System.out.println(list);
		list.add(4, 16);
		System.out.println(list);
						
	}
}
